# STRIGOI BF6 — Pack de distribución (v5.2.1)

Contiene:
- `bf6_local_server_input_mac_v5_2_1.py` — Servidor Matrix con ventana y hotkeys
- `strigoi_hud_matrix_v5.html` — HUD Matrix Verde (tendencia KD, últimas partidas, 🗑️)
- `strigoi_bf6_sync_v2_1_1_classic_resetfix.html` — App clásica (reset arreglado)
- `bf6_totals.json` — Datos locales
- `Iniciar_STRIGOI.command` — Lanzador macOS (doble clic)
- `Start_STRIGOI_Windows.bat` — Lanzador Windows

## macOS
1) Descomprime el ZIP.
2) (Solo la primera vez) da permisos al lanzador:
   chmod +x Iniciar_STRIGOI.command
3) Doble clic en Iniciar_STRIGOI.command
4) Abre el HUD: strigoi_hud_matrix_v5.html

Permisos (para hotkeys): Ajustes → Privacidad → Accesibilidad + Monitorización de entradas (Terminal y Python.app).

## Windows
- Requiere Python 3 en PATH. Doble clic en Start_STRIGOI_Windows.bat

## Notas
- Datos en bf6_totals.json
- Botón 🗑️ del HUD borra solo las últimas 5 partidas del historial
